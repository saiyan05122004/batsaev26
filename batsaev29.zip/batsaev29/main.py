import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget, QListWidget, QComboBox, QTableWidget, QTableWidgetItem, QMessageBox
import sqlite3


class PharmacyApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Учёт лекарств в аптеке')
        self.setGeometry(100, 100, 800, 600)

        self.btn_show_suppliers = QPushButton('Показать поставщиков', self)
        self.btn_show_suppliers.clicked.connect(self.show_suppliers)

        self.btn_show_medicines = QPushButton('Список лекарств', self)
        self.btn_show_medicines.clicked.connect(self.show_medicines)

        self.btn_show_supplies_info = QPushButton('Сведения о поставках', self)
        self.btn_show_supplies_info.clicked.connect(self.show_supplies_info)

        self.btn_calculate_stock = QPushButton('Показать наличие лекарства', self)
        self.btn_calculate_stock.clicked.connect(self.calculate_stock)

        self.btn_top_selling = QPushButton('Топ-3 продаж', self)
        self.btn_top_selling.clicked.connect(self.top_selling)

        self.supplier_combo = QComboBox(self)
        self.supplier_combo.setVisible(False)
        self.supplier_combo.currentIndexChanged.connect(self.show_supplier_medicines)

        self.btn_edit = QPushButton('Редактировать', self)
        self.btn_edit.clicked.connect(self.edit_selected_item)

        self.btn_delete = QPushButton('Удалить', self)
        self.btn_delete.clicked.connect(self.delete_selected_item)

        layout = QVBoxLayout()
        layout.addWidget(self.btn_show_suppliers)
        layout.addWidget(self.btn_show_medicines)
        layout.addWidget(self.btn_show_supplies_info)
        layout.addWidget(self.btn_calculate_stock)
        layout.addWidget(self.btn_top_selling)
        layout.addWidget(self.supplier_combo)
        layout.addWidget(self.btn_edit)
        layout.addWidget(self.btn_delete)

        self.table_widget = QTableWidget(self)
        layout.addWidget(self.table_widget)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def show_suppliers(self):
        conn = sqlite3.connect('pharmacy.db')
        cursor = conn.cursor()

        cursor.execute("""
        SELECT DISTINCT supplier_name FROM supplies;
        """)
        suppliers = cursor.fetchall()

        conn.close()

        supplier_list = [supplier[0] for supplier in suppliers]
        self.supplier_combo.clear()
        self.supplier_combo.addItems(supplier_list)
        self.supplier_combo.setVisible(True)

    def show_supplier_medicines(self):
        supplier_name = self.supplier_combo.currentText()

        conn = sqlite3.connect('pharmacy.db')
        cursor = conn.cursor()

        cursor.execute("""
        SELECT medicines.name, supplies.quantity
        FROM medicines JOIN supplies ON medicines.id = supplies.medicine_id
        WHERE supplies.supplier_name = ?;
        """, (supplier_name,))

        medicines = cursor.fetchall()

        conn.close()

        self.show_table(medicines, ['Лекарство', 'Количество'])

    def show_medicines(self):
        conn = sqlite3.connect('pharmacy.db')
        cursor = conn.cursor()

        cursor.execute("""
        SELECT name, price FROM medicines;
        """)
        medicines = cursor.fetchall()

        conn.close()

        self.show_table(medicines, ['Лекарство', 'Цена'])

    def show_supplies_info(self):
        conn = sqlite3.connect('pharmacy.db')
        cursor = conn.cursor()

        cursor.execute("""
        SELECT medicines.name, supplies.date, supplies.quantity
        FROM medicines JOIN supplies ON medicines.id = supplies.medicine_id;
        """)
        supplies = cursor.fetchall()

        conn.close()

        self.show_table(supplies, ['Лекарство', 'Дата', 'Количество'])

    def calculate_stock(self):
        conn = sqlite3.connect('pharmacy.db')
        cursor = conn.cursor()

        cursor.execute("""
        SELECT name, SUM(quantity)
        FROM medicines JOIN supplies ON medicines.id = supplies.medicine_id
        GROUP BY name;
        """)
        stock = cursor.fetchall()

        conn.close()

        self.show_table(stock, ['Лекарство', 'Количество'])

    def top_selling(self):
        conn = sqlite3.connect('pharmacy.db')
        cursor = conn.cursor()

        cursor.execute("""
        SELECT name, SUM(quantity)
        FROM medicines JOIN sales ON medicines.id = sales.medicine_id
        GROUP BY name
        ORDER BY SUM(quantity) DESC
        LIMIT 3;
        """)
        top_selling = cursor.fetchall()

        conn.close()

        self.show_table(top_selling, ['Лекарство', 'Продажи'])

    def edit_selected_item(self):
        selected_row = self.table_widget.currentRow()
        if selected_row == -1:
            self.showMessageBox('Ошибка', 'Выберите элемент для редактирования.')
            return


        item_id = self.table_widget.item(selected_row, 0).text()


    def delete_selected_item(self):
        selected_row = self.table_widget.currentRow()
        if selected_row == -1:
            self.showMessageBox('Ошибка', 'Выберите элемент для удаления.')
            return

        confirmation = QMessageBox.question(self, 'Подтверждение', 'Вы уверены, что хотите удалить выбранный элемент?',
                                            QMessageBox.Yes | QMessageBox.No)
        if confirmation == QMessageBox.Yes:
            item_id = self.table_widget.item(selected_row, 0).text()


            conn = sqlite3.connect('pharmacy.db')
            cursor = conn.cursor()


            if self.table_widget.horizontalHeaderItem(1).text() == 'Цена':
                cursor.execute("DELETE FROM medicines WHERE id=?", (item_id,))
            elif self.table_widget.horizontalHeaderItem(1).text() == 'Количество':
                cursor.execute("DELETE FROM supplies WHERE id=?", (item_id,))
            elif self.table_widget.horizontalHeaderItem(1).text() == 'Продажи':
                cursor.execute("DELETE FROM sales WHERE id=?", (item_id,))

            conn.commit()
            conn.close()


            self.refresh_table()

    def refresh_table(self):

        if self.btn_show_suppliers.text() == 'Показать поставщиков':
            self.show_suppliers()
        elif self.btn_show_medicines.text() == 'Список лекарств':
            self.show_medicines()
        elif self.btn_show_supplies_info.text() == 'Сведения о поставках':
            self.show_supplies_info()
        elif self.btn_calculate_stock.text() == 'Показать наличие лекарства':
            self.calculate_stock()
        elif self.btn_top_selling.text() == 'Топ-3 продаж':
            self.top_selling()

    def show_table(self, data, headers):
        self.table_widget.clear()
        self.table_widget.setRowCount(len(data))
        self.table_widget.setColumnCount(len(headers))
        self.table_widget.setHorizontalHeaderLabels(headers)

        for row_number, row_data in enumerate(data):
            for column_number, item in enumerate(row_data):
                self.table_widget.setItem(row_number, column_number, QTableWidgetItem(str(item)))

    def showMessageBox(self, title, message):
        msg_box = QMessageBox()
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.exec_()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = PharmacyApp()
    window.show()
    sys.exit(app.exec_())




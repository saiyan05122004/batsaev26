import sqlite3


conn = sqlite3.connect('pharmacy.db')
cursor = conn.cursor()

cursor.execute("INSERT INTO medicines (name, price) VALUES ('Аспирин', 50.0)")
cursor.execute("INSERT INTO medicines (name, price) VALUES ('Ношпа', 100.0)")
cursor.execute("INSERT INTO medicines (name, price) VALUES ('Парацетамол', 40.0)")



cursor.execute(
    "INSERT INTO supplies (supplier_name, date, medicine_id, quantity) VALUES ('ООО ГосЗдрав', '2024-04-01', 1, 100)")
cursor.execute(
    "INSERT INTO supplies (supplier_name, date, medicine_id, quantity) VALUES ('ООО ЖитьЗдорово', '2024-04-02', 2, 50)")
cursor.execute(
    "INSERT INTO supplies (supplier_name, date, medicine_id, quantity) VALUES ('ООО Московский', '2024-04-03', 3, 200)")
cursor.execute(
    "INSERT INTO supplies (supplier_name, date, medicine_id, quantity) VALUES ('ООО Здрав', '2024-04-04', 2, 75)")
cursor.execute(
    "INSERT INTO supplies (supplier_name, date, medicine_id, quantity) VALUES ('ООО Здрав', '2024-04-04', 1, 15)")


cursor.execute("INSERT INTO sales (date, medicine_id, quantity) VALUES ('2024-04-05', 1, 20)")
cursor.execute("INSERT INTO sales (date, medicine_id, quantity) VALUES ('2024-04-06', 2, 30)")
cursor.execute("INSERT INTO sales (date, medicine_id, quantity) VALUES ('2024-04-07', 3, 50)")
cursor.execute("INSERT INTO sales (date, medicine_id, quantity) VALUES ('2024-04-08', 1, 10)")
cursor.execute("INSERT INTO sales (date, medicine_id, quantity) VALUES ('2024-04-09', 2, 40)")
cursor.execute("INSERT INTO sales (date, medicine_id, quantity) VALUES ('2024-04-10', 1, 25)")

conn.commit()
conn.close()